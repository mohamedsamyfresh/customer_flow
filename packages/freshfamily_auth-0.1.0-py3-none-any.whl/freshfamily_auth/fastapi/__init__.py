"""FastAPI integration for freshfamily-auth.

Importing this subpackage requires the ``fastapi`` extra:
``pip install freshfamily-auth[fastapi]``.
"""

from .handlers import install_exception_handlers
from .kit import AuthKit

__all__ = ["AuthKit", "install_exception_handlers"]
