"""``AuthKit``: instance-based auth kit for a FastAPI service.

Owns config, the lazily-built ``JwksClient`` / static key, the bearer security
dependency, and the claims mapper. Provides the dependency factories
(``current_user``, ``require_permission``, ``require_role``, ``require_subject_type``)
and lifecycle helpers (``prefetch``, ``aclose``, ``lifespan``).
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager
from typing import Annotated, Any, cast

from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from fastapi import Depends, FastAPI, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ..config import AuthConfig, AuthConfigProtocol
from ..decoding import decode_async, decode_sync
from ..exceptions import InsufficientPermissionsError, InvalidTokenError, MissingTokenError
from ..jwks import JwksClient
from ..payload import ClaimsMapper, TokenPayload, default_mapper


class AuthKit:
    """Instance-based auth kit for a FastAPI service.

    Owns the ``AuthConfig``, a lazily-built ``JwksClient`` (for the async/JWKS
    path), a lazily-built static ``RSAPublicKey`` (for the sync/PEM path), the
    FastAPI ``HTTPBearer`` security dependency, and the claims mapper. Provides
    the dependency factories (``current_user``, ``require_permission``,
    ``require_role``, ``require_subject_type``) and the lifecycle helpers
    (``prefetch``, ``aclose``, ``lifespan``).

    Instance-based (not module-global) so a service can hold multiple kits
    during an issuer cutover, and so the library is trivially testable.

    Args:
        config: An ``AuthConfig`` or any object satisfying
            ``AuthConfigProtocol`` (e.g. a pydantic ``Settings``). A non-
            ``AuthConfig`` object is copied field-by-field into an
            ``AuthConfig`` internally.
        claims_mapper: Callable mapping decoded claims to a ``TokenPayload``.
            Defaults to ``default_mapper`` (reads ``sub``/``roles``/``permissions``
            using the configured claim names). Pass a custom mapper for
            Keycloak's nested ``realm_access.roles`` etc.
    """

    def __init__(
        self,
        config: AuthConfig | AuthConfigProtocol,
        *,
        claims_mapper: ClaimsMapper = default_mapper,
    ):
        if isinstance(config, AuthConfig):
            self._config = config
        else:
            # Copy the 15 protocol fields into a frozen AuthConfig. This lets a
            # service pass its pydantic Settings directly without adapter boilerplate.
            self._config = AuthConfig(
                jwks_url=config.jwks_url,
                issuer=config.issuer,
                audience=config.audience,
                algorithms=config.algorithms,
                cache_ttl_seconds=config.cache_ttl_seconds,
                fetch_timeout_seconds=config.fetch_timeout_seconds,
                public_key_pem=config.public_key_pem,
                rotation_retry=config.rotation_retry,
                app_env=config.app_env,
                dev_bypass_role=config.dev_bypass_role,
                required_claims=config.required_claims,
                leeway=config.leeway,
                sub_claim=config.sub_claim,
                roles_claim=config.roles_claim,
                permissions_claim=config.permissions_claim,
            )
        self._mapper = claims_mapper
        self._jwks_client: JwksClient | None = None
        self._static_key: RSAPublicKey | None = None
        self._bearer = HTTPBearer(auto_error=False)

    def __deepcopy__(self, memo: dict[int, Any]) -> AuthKit:
        # AuthKit is a shared service instance; returning self avoids deep-copying
        # non-copyable internals (HTTPBearer holds an RLock, JwksClient holds an
        # asyncio.Lock) when FastAPI/Pydantic deep-copies dependency defaults that
        # capture this kit via a bound method (self._get_current_user).
        memo[id(self)] = self
        return self

    @property
    def config(self) -> AuthConfig:
        """The resolved ``AuthConfig`` (a copy if a protocol was passed in)."""
        return self._config

    def _ensure_jwks_client(self) -> JwksClient:
        if self._jwks_client is None:
            if self._config.jwks_url is None:
                raise InvalidTokenError("no JWKS URL configured")
            self._jwks_client = JwksClient(
                self._config.jwks_url,
                cache_ttl=self._config.cache_ttl_seconds,
                fetch_timeout=self._config.fetch_timeout_seconds,
            )
        return self._jwks_client

    def _ensure_static_key(self) -> RSAPublicKey:
        key = self._static_key
        if key is None:
            pem = self._config.public_key_pem
            if pem is None:
                raise InvalidTokenError("no static key configured")
            # Normalize \n literals (common in env-var-sourced PEMs) before parsing.
            pem = pem.replace("\\n", "\n").encode()
            try:
                key = cast(RSAPublicKey, load_pem_public_key(pem))
            except (ValueError, TypeError) as exc:
                raise InvalidTokenError(f"invalid static public key: {exc}") from exc
            self._static_key = key
        return key

    async def decode_async(self, token: str) -> TokenPayload:
        """Verify a token via the JWKS path (no PEM fallback).

        This is the path used by ``_get_current_user`` in request handlers. It
        is JWKS-only by design: a runtime PEM fallback would accept tokens
        signed by a rotated-out key. Raises ``InvalidTokenError`` if
        ``jwks_url`` is unset.
        """
        client = self._ensure_jwks_client()
        return await decode_async(token, self._config, jwks_client=client, mapper=self._mapper)

    def decode_sync(self, token: str) -> TokenPayload:
        """Verify a token via the static PEM path (no JWKS fetch).

        For tests/CLI only — never call from a request handler. Raises
        ``InvalidTokenError`` if ``public_key_pem`` is unset or malformed.
        """
        key = self._ensure_static_key()
        return decode_sync(token, self._config, static_key=key, mapper=self._mapper)

    async def prefetch(self) -> None:
        """Eagerly fetch the JWKS once at startup.

        No-op when ``jwks_url`` is unset. A fetch failure propagates (the
        service decides whether to start anyway — stale-on-failure will help on
        the next fetch — or fail fast). Call this in your ``lifespan`` so the
        first request doesn't pay the JWKS fetch latency and an endpoint
        outage surfaces at boot, not on the first user request.
        """
        if self._config.jwks_url is None:
            return
        client = self._ensure_jwks_client()
        await client._refresh()  # type: ignore[misc]

    async def _get_current_user(self, request: Request) -> TokenPayload:
        """FastAPI dependency: extract the bearer token and return the decoded payload.

        Raises ``MissingTokenError`` if the Authorization header is absent or
        not a bearer scheme. Raises ``InvalidTokenError``/``ExpiredTokenError``
        /``SignatureVerificationError`` from the decode path. All are
        ``AuthError`` subclasses, mapped to 401 by ``install_exception_handlers``.
        """
        credentials: HTTPAuthorizationCredentials | None = await self._bearer(request)
        if credentials is None or not credentials.credentials:
            raise MissingTokenError("Authorization header missing or invalid")
        return await self.decode_async(credentials.credentials)

    @property
    def current_user(self) -> Any:
        """Type-annotation alias for the current-user dependency.

        Usage::

            CurrentUser = auth.current_user

            @app.get("/me")
            async def me(user: CurrentUser):
                return {"sub": user.sub}

        Returns an ``Annotated[TokenPayload, Depends(self._get_current_user)]``.
        Typed as ``Any`` because pyright cannot fully type an ``Annotated``
        returned from a property; the runtime object is correct and FastAPI's
        dependency resolution reads the metadata as expected.
        """
        return Annotated[TokenPayload, Depends(self._get_current_user)]

    def _dev_bypass(self, user: TokenPayload) -> bool:
        """True if dev bypass applies: ``app_env == "development"`` AND a bypass
        role is configured AND the user holds it. Preserves the Smart-Track dev
        flow where ``admin-dev`` users skip permission/role/subject_type gates.
        """
        return self._config.app_env == "development" and self._config.dev_bypass_role is not None and user.has_role(self._config.dev_bypass_role)

    def require_permission(self, permission: str | Any) -> Callable[..., Any]:
        """Dependency factory: require the user to hold ``permission``.

        Accepts a ``str`` or an enum (coerced via ``str(perm)``) so services can
        pass their ``Permission`` enum directly. Raises
        ``InsufficientPermissionsError`` (→ 403) if the user lacks it and the
        dev bypass does not apply.
        """
        perm = str(permission)

        async def _check(user: TokenPayload = Depends(self._get_current_user)) -> None:
            if self._dev_bypass(user):
                return
            if not user.has_permission(perm):
                raise InsufficientPermissionsError(f"Missing permission: {perm}")

        _check.__name__ = f"require_permission_{perm}"
        return _check

    def require_role(self, role: str | Any) -> Callable[..., Any]:
        """Dependency factory: require the user to hold ``role``.

        Accepts a ``str`` or an enum (coerced via ``str(role)``). Raises
        ``InsufficientPermissionsError`` (→ 403) if the user lacks it and the
        dev bypass does not apply.
        """
        role_str = str(role)

        async def _check(user: TokenPayload = Depends(self._get_current_user)) -> None:
            if self._dev_bypass(user):
                return
            if not user.has_role(role_str):
                raise InsufficientPermissionsError(f"Missing role: {role_str}")

        _check.__name__ = f"require_role_{role_str}"
        return _check

    def require_subject_type(self, value: str) -> Callable[..., Any]:
        """Dependency factory: require ``raw["subject_type"] == value``.

        Reads the ``subject_type`` claim from the raw claims dict (the field is
        issuer-specific, so it is not on ``TokenPayload`` directly). Raises
        ``InsufficientPermissionsError`` (→ 403) if it does not match and the
        dev bypass does not apply.
        """

        async def _check(user: TokenPayload = Depends(self._get_current_user)) -> None:
            if self._dev_bypass(user):
                return
            if user.raw.get("subject_type") != value:
                raise InsufficientPermissionsError(f"Missing subject_type: {value}")

        _check.__name__ = f"require_subject_type_{value}"
        return _check

    def install_exception_handlers(self, app: FastAPI) -> None:
        """Register ``AuthError`` → 401/403 JSON handlers on ``app``.

        Delegates to ``freshfamily_auth.fastapi.handlers.install_exception_handlers``.
        ``InsufficientPermissionsError`` → 403; all other ``AuthError`` → 401.
        Body: ``{"detail": "<message>"}``.
        """
        from .handlers import install_exception_handlers

        install_exception_handlers(app)

    async def aclose(self) -> None:
        """Close the cached ``JwksClient`` (and its httpx client). Safe to repeat."""
        if self._jwks_client is not None:
            await self._jwks_client.aclose()

    @asynccontextmanager
    async def lifespan(self, app: FastAPI) -> AsyncGenerator[None]:
        """Convenience lifespan: ``prefetch`` on startup, ``aclose`` on shutdown.

        Usage::

            app = FastAPI(lifespan=auth.lifespan)
        """
        await self.prefetch()
        yield
        await self.aclose()
