from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from ..exceptions import AuthError, InsufficientPermissionsError


def install_exception_handlers(app: FastAPI) -> None:
    """Register a single handler mapping every ``AuthError`` to a JSON response.

    - ``InsufficientPermissionsError`` → 403
    - all other ``AuthError`` (``MissingTokenError``, ``InvalidTokenError``,
      ``SignatureVerificationError``, ``ExpiredTokenError``) → 401
    - body: ``{"detail": "<message>"}``

    Register once at startup: ``auth.install_exception_handlers(app)`` (or
    import and call this function directly).
    """

    @app.exception_handler(AuthError)
    async def _auth_error_handler(request: Request, exc: AuthError) -> JSONResponse:  # type: ignore[reportUnusedFunction]
        status = 403 if isinstance(exc, InsufficientPermissionsError) else 401
        return JSONResponse(status_code=status, content={"detail": str(exc)})
