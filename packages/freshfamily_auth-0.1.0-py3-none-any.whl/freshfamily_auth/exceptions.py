"""Exception hierarchy for freshfamily-auth.

All auth failures raised by the library are ``AuthError`` subclasses, so a
single ``except AuthError`` in a handler/dependency covers every case.
``install_exception_handlers`` maps the hierarchy to HTTP responses:
``InsufficientPermissionsError`` → 403, everything else → 401.
"""


class AuthError(Exception):
    """Base for all auth errors raised by the library.

    All exceptions in this hierarchy are mapped to HTTP responses by
    ``install_exception_handlers``: ``InsufficientPermissionsError`` → 403,
    everything else → 401. Non-``AuthError`` exceptions are never raised by
    the library's decode path — PyJWT errors, JWKS fetch failures, malformed
    JWKs, and mapper errors all converge to an ``AuthError`` subclass.
    """


class MissingTokenError(AuthError):
    """No Authorization header or no bearer credentials in the request."""


class InvalidTokenError(AuthError):
    """Token is malformed, the key was not found, decode failed, or a required claim is missing.

    This is the generic "the token is not usable" error. It is the catch-all
    for PyJWT ``PyJWTError`` (except signature and expiry, which have dedicated
    subclasses), for JWKS lookup/fetch failures, and for mapper exceptions.
    """


class SignatureVerificationError(InvalidTokenError):
    """The token's signature is invalid.

    Distinguished from ``InvalidTokenError`` so the rotation-retry layer in
    ``decode_async`` can target *only* signature failures — a stale JWKS cache
    holding a rotated-out key produces this error, triggering one invalidate +
    re-fetch + retry. Other decode failures (expired, malformed, missing claims)
    do not trigger a retry.
    """


class ExpiredTokenError(AuthError):
    """The token's ``exp`` claim is in the past (outside any configured ``leeway``)."""


class InsufficientPermissionsError(AuthError):
    """The user lacks a required permission, role, or ``subject_type``.

    Raised by ``require_permission`` / ``require_role`` / ``require_subject_type``
    when the check fails and the dev bypass does not apply. Mapped to HTTP 403.
    """
