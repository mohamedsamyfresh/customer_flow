"""Token decoding: signature/issuer/audience/expiry verification + claims mapping.

Exposes ``decode_async`` (JWKS path, with rotation retry) and ``decode_sync``
(static PEM path, for tests/CLI). Both converge on ``_verify_token``, which runs
PyJWT's ``decode`` with a strict exception-catch order and then the claims mapper.
"""

from __future__ import annotations

import httpx
import jwt
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from jwt.exceptions import ExpiredSignatureError, InvalidSignatureError, PyJWTError

from .config import AuthConfig
from .exceptions import AuthError, ExpiredTokenError, InvalidTokenError, SignatureVerificationError
from .jwks import JwksClient
from .payload import ClaimsMapper, TokenPayload, default_mapper


def _peek_kid(token: str) -> str | None:
    """Read the ``kid`` from the token header without verifying the signature.

    Returns ``None`` if the header is malformed or has no ``kid``. Used to select
    the right key from the JWKS cache before the (expensive) signature check.
    """
    try:
        return jwt.get_unverified_header(token).get("kid")
    except Exception:
        return None


def _verify_token(token: str, key: RSAPublicKey, config: AuthConfig, mapper: ClaimsMapper) -> TokenPayload:
    """Verify the token's signature/issuer/audience/expiry and run the claims mapper.

    PyJWT exception catch order is most-specific first:
        ``ExpiredSignatureError`` → ``ExpiredTokenError``
        ``InvalidSignatureError`` → ``SignatureVerificationError``
        other ``PyJWTError``     → ``InvalidTokenError``

    The ``SignatureVerificationError`` distinction matters: ``decode_async``'s
    rotation-retry layer targets *only* signature failures (a stale cached key),
    not expired or malformed tokens.

    The mapper runs outside PyJWT's try/except. An ``AuthError`` it raises
    propagates as-is; any other exception (e.g. ``TypeError`` from a malformed
    claim like ``roles: 5``) is mapped to ``InvalidTokenError`` so a bad claim
    never escapes as a 500.
    """
    try:
        claims = jwt.decode(
            token,
            key=key,
            algorithms=list(config.algorithms),
            options={"verify_signature": True, "require": list(config.required_claims)},
            audience=config.audience,
            issuer=config.issuer,
            leeway=config.leeway,
        )
    except ExpiredSignatureError as exc:
        raise ExpiredTokenError(str(exc)) from exc
    except InvalidSignatureError as exc:
        raise SignatureVerificationError(str(exc)) from exc
    except PyJWTError as exc:
        raise InvalidTokenError(str(exc)) from exc
    try:
        return mapper(claims, config)
    except AuthError:
        raise
    except Exception as exc:
        raise InvalidTokenError(str(exc)) from exc


async def _resolve_key(jwks_client: JwksClient, kid: str | None) -> RSAPublicKey:
    """Resolve a key via JWKS, mapping lookup/fetch/parse failures to ``InvalidTokenError``.

    Catches ``ValueError`` (unknown kid, empty keyset), ``TypeError`` (malformed JWK
    fields), ``httpx.HTTPError`` (JWKS endpoint unreachable / non-2xx), and
    ``PyJWTError`` (malformed JWK from ``RSAAlgorithm.from_jwk``). All converge to
    ``InvalidTokenError`` so the FastAPI handler returns 401, never 500.
    """
    try:
        return await jwks_client.get_key(kid)
    except (ValueError, TypeError, httpx.HTTPError, PyJWTError) as exc:
        raise InvalidTokenError(str(exc)) from exc


async def decode_async(
    token: str,
    config: AuthConfig,
    *,
    jwks_client: JwksClient | None = None,
    static_key: RSAPublicKey | None = None,
    mapper: ClaimsMapper = default_mapper,
) -> TokenPayload:
    """Verify a JWT and return the mapped payload (async path).

    Provide either ``jwks_client`` (preferred — fetches the key by ``kid`` and
    supports rotation retry) or ``static_key`` (a pinned RSA public key, for
    tests). Raises ``InvalidTokenError`` if neither is given.

    Rotation retry: when ``config.rotation_retry`` is True and the first
    ``_verify_token`` raises ``SignatureVerificationError``, the JWKS cache is
    invalidated, the key is re-resolved, and ``_verify_token`` runs once more.
    This handles the window where the issuer has rotated to a new key but the
    consumer still has the old one cached. Only signature failures trigger a
    retry — expired/malformed tokens are not retried.
    """
    if jwks_client is None and static_key is None:
        raise InvalidTokenError("no key source configured")
    kid = _peek_kid(token)
    if jwks_client is not None:
        key = await _resolve_key(jwks_client, kid)
        try:
            return _verify_token(token, key, config, mapper)
        except SignatureVerificationError:
            if config.rotation_retry:
                jwks_client.invalidate()
                key = await _resolve_key(jwks_client, kid)
                return _verify_token(token, key, config, mapper)
            raise
    assert static_key is not None
    return _verify_token(token, static_key, config, mapper)


def decode_sync(
    token: str,
    config: AuthConfig,
    *,
    static_key: RSAPublicKey | None = None,
    mapper: ClaimsMapper = default_mapper,
) -> TokenPayload:
    """Verify a JWT against a static RSA public key (sync path).

    For tests, CLI scripts, and Alembic — never use in a FastAPI request handler.
    The async path (``decode_async`` via ``AuthKit``) is JWKS-only by design: a
    runtime PEM fallback would accept tokens signed by a rotated-out key.
    Raises ``InvalidTokenError`` if ``static_key`` is None.
    """
    if static_key is None:
        raise InvalidTokenError("no static key configured")
    return _verify_token(token, static_key, config, mapper)
