"""freshfamily-auth: shared JWT/JWKS authentication for Fresh Family microservices.

Core (no FastAPI required): ``AuthConfig``, ``AuthConfigProtocol``, ``JwksClient``,
``decode_async``, ``decode_sync``, ``TokenPayload``, ``ClaimsMapper``,
``default_mapper``, and the ``AuthError`` hierarchy.

FastAPI integration: ``AuthKit`` and ``install_exception_handlers``. ``AuthKit``
is imported lazily via ``__getattr__`` so that ``import freshfamily_auth`` does
not pull in FastAPI — install with ``pip install freshfamily-auth[fastapi]`` to
use it.
"""

from __future__ import annotations

from typing import Any

from .config import AuthConfig, AuthConfigProtocol
from .decoding import decode_async, decode_sync
from .exceptions import (
    AuthError,
    ExpiredTokenError,
    InsufficientPermissionsError,
    InvalidTokenError,
    MissingTokenError,
    SignatureVerificationError,
)
from .jwks import JwksClient
from .payload import ClaimsMapper, TokenPayload, default_mapper

__all__ = [
    "AuthConfig",
    "AuthConfigProtocol",
    "AuthError",
    "AuthKit",  # type: ignore[reportUnsupportedDunderAll]  # provided via __getattr__
    "ClaimsMapper",
    "ExpiredTokenError",
    "InsufficientPermissionsError",
    "InvalidTokenError",
    "JwksClient",
    "MissingTokenError",
    "SignatureVerificationError",
    "TokenPayload",
    "decode_async",
    "decode_sync",
    "default_mapper",
]


def __getattr__(name: str) -> Any:
    """Lazily import AuthKit so core imports don't require the optional fastapi extra."""
    if name == "AuthKit":
        from .fastapi.kit import AuthKit

        return AuthKit
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)
