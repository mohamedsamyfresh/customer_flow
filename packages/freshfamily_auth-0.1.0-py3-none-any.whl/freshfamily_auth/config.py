"""Configuration for JWT verification: ``AuthConfig`` and ``AuthConfigProtocol``."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class AuthConfig:
    """Immutable configuration for JWT verification.

    All fields have defaults so services can construct it from their own Settings.
    Frozen + slots so it is hashable and safe to share across requests/threads.
    ``algorithms``/``required_claims`` are tuples (not lists) for the same reason.

    Attributes:
        jwks_url: JWKS endpoint. ``None`` disables the async path (``decode_async``
            raises ``InvalidTokenError``). Required for FastAPI request handlers.
        issuer: Expected ``iss`` claim. ``None`` skips issuer verification.
        audience: Expected ``aud`` claim. ``None`` skips audience verification
            (PyJWT requires explicit opt-out via ``options={"verify_aud": False}``).
        algorithms: Tuple of accepted signing algorithms. Keep this narrow —
            never include ``"none"``. Default ``("RS256",)``.
        cache_ttl_seconds: JWKS key cache lifetime. Keys are reused until this
            elapses, after which the next ``get_key`` triggers a refresh.
        fetch_timeout_seconds: httpx timeout for a single JWKS fetch.
        public_key_pem: Static RSA public key PEM, for ``decode_sync`` only
            (tests, CLI scripts). Never used by ``decode_async`` — a runtime PEM
            fallback would accept tokens signed by a rotated-out key. ``\\n``
            literals in the string are normalized on first use.
        rotation_retry: On ``SignatureVerificationError``, invalidate the JWKS
            cache and retry once. Handles the window where the issuer has rotated
            to a new key but the consumer still has the old one cached.
        app_env: Environment name. ``"development"`` enables the dev bypass.
        dev_bypass_role: Role that bypasses ``require_*`` checks when
            ``app_env == "development"``. ``None`` disables the bypass.
        required_claims: Claim names that must be present (passed to PyJWT's
            ``require`` option). Defaults to the JWT minimum.
        leeway: Clock-skew tolerance in seconds. Set ``30.0`` in production to
            absorb NTP drift between issuer and consumer clocks.
        sub_claim: Claim name holding the subject (employee code). Rename for
            issuers that use a non-standard claim.
        roles_claim: Claim name holding the roles list.
        permissions_claim: Claim name holding the permissions list.
    """

    jwks_url: str | None = None
    issuer: str | None = None
    audience: str | None = None
    algorithms: tuple[str, ...] = ("RS256",)
    cache_ttl_seconds: float = 3600.0
    fetch_timeout_seconds: float = 5.0
    public_key_pem: str | None = None
    rotation_retry: bool = True
    app_env: str | None = None
    dev_bypass_role: str | None = None
    required_claims: tuple[str, ...] = ("sub", "exp", "iat")
    leeway: float = 0.0
    sub_claim: str = "sub"
    roles_claim: str = "roles"
    permissions_claim: str = "permissions"


@runtime_checkable
class AuthConfigProtocol(Protocol):
    """Duck-typing interface for a service's Settings object."""

    jwks_url: str | None
    issuer: str | None
    audience: str | None
    algorithms: tuple[str, ...]
    cache_ttl_seconds: float
    fetch_timeout_seconds: float
    public_key_pem: str | None
    rotation_retry: bool
    app_env: str | None
    dev_bypass_role: str | None
    required_claims: tuple[str, ...]
    leeway: float
    sub_claim: str
    roles_claim: str
    permissions_claim: str
