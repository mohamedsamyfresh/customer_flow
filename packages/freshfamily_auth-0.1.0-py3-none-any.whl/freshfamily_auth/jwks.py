"""Async JWKS client with TTL cache, stale-on-failure, and key rotation support."""

from __future__ import annotations

import asyncio
import logging
from typing import cast

import httpx
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from jwt.algorithms import RSAAlgorithm

logger = logging.getLogger(__name__)


class JwksClient:
    """Async JWKS client with TTL cache, stale-on-failure, and key rotation support.

    Designed to be owned by ``AuthKit`` (which builds it lazily from
    ``config.jwks_url``) or used standalone by core-only consumers.

    Features:
        - **TTL cache:** keys fetched once, reused until ``cache_ttl`` elapses.
        - **Stampede protection:** an ``asyncio.Lock`` around the fetch so
          concurrent requests trigger one fetch, not N.
        - **Stale-on-failure:** if a refresh fetch fails and the cache is
          non-empty, the stale cache is kept (logged as a warning). An empty
          cache + fetch failure re-raises.
        - **Rotation-aware miss:** when ``kid`` is present but not in a
          fresh cache, ``get_key`` forces one refresh before refusing — so an
          IdP key rotation heals on the first request with the new ``kid``,
          not after ``cache_ttl``. Only after the refresh confirms the ``kid``
          is genuinely absent does it raise ``ValueError``.
        - **Single-key fallback:** when ``kid`` is ``None``/absent and the JWKS
          has exactly one RSA key, that key is used.
        - **Non-RSA keys skipped:** only ``kty == "RSA"`` keys are cached.
    """

    def __init__(self, jwks_url: str, *, cache_ttl: float = 3600.0, fetch_timeout: float = 5.0):
        self._jwks_url = jwks_url
        self._cache_ttl = cache_ttl
        self._fetch_timeout = fetch_timeout
        self._cache: dict[str | None, RSAPublicKey] = {}
        self._fetched_at: float = 0.0
        self._lock = asyncio.Lock()
        self._client: httpx.AsyncClient | None = None

    @property
    def _http_client(self) -> httpx.AsyncClient:
        # Lazily created so a never-used client (e.g. jwks_url unset) costs nothing.
        # Only ever reached via _refresh, which holds self._lock, so no lock here.
        if self._client is None:
            self._client = httpx.AsyncClient()
        return self._client

    async def aclose(self) -> None:
        """Close the cached httpx client. Safe to call multiple times.

        Acquires the refresh lock so shutdown cannot overlap an in-flight fetch.
        """
        async with self._lock:
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    async def _refresh(self, *, force: bool = False) -> None:
        """Fetch the JWKS and rebuild the cache, holding the lock.

        If the cache is non-empty and the fetch fails, the stale cache is kept
        (a warning is logged). If the cache is empty, the error re-raises so the
        caller (``_resolve_key``) can map it to ``InvalidTokenError``.

        ``force`` bypasses the TTL freshness check — used by ``get_key``'s
        rotation-aware miss path so a present-but-unknown ``kid`` triggers a
        fetch even when the cache is fresh.
        """
        async with self._lock:
            now = asyncio.get_running_loop().time()
            if not force and self._cache and now - self._fetched_at < self._cache_ttl:
                return
            try:
                response = await self._http_client.get(self._jwks_url, timeout=self._fetch_timeout)
                response.raise_for_status()
                jwks = response.json()
            except Exception as exc:
                if self._cache:
                    logger.warning("JWKS fetch failed, using stale cache: %s", exc)
                    return
                raise
            new_cache: dict[str | None, RSAPublicKey] = {}
            for key in jwks.get("keys", []):
                if key.get("kty") != "RSA":
                    continue
                kid = key.get("kid")
                new_cache[kid] = cast(RSAPublicKey, RSAAlgorithm.from_jwk(key))
            if not new_cache:
                raise ValueError("JWKS returned no RSA keys")
            self._cache = new_cache
            self._fetched_at = now

    async def get_key(self, kid: str | None) -> RSAPublicKey:
        """Return the RSA public key for ``kid``, refreshing the cache first if stale.

        Raises ``ValueError`` if the key is not found (and the single-key fallback
        does not apply). ``_resolve_key`` in ``decoding.py`` maps this to
        ``InvalidTokenError`` so callers see an ``AuthError``, not a 500.
        """
        now = asyncio.get_running_loop().time()
        if not self._cache or now - self._fetched_at >= self._cache_ttl:
            await self._refresh()
        if kid in self._cache:
            return self._cache[kid]
        # ponytail: present-but-unknown kid with a fresh cache = rotation window
        # (IdP published a new kid, we still hold the old keyset). Force one
        # refresh so a rotation heals on this request, not after cache_ttl. If
        # the refresh confirms the kid is genuinely absent, fall through to raise.
        if kid is not None:
            await self._refresh(force=True)
            if kid in self._cache:
                return self._cache[kid]
        # single-key fallback only when kid is None/absent. A present but unknown
        # kid is suspicious (possible downgrade) — refuse rather than guess.
        if kid is None and len(self._cache) == 1:
            return next(iter(self._cache.values()))
        raise ValueError(f"no key for kid={kid!r}")

    def invalidate(self) -> None:
        """Force a JWKS refresh on the next ``get_key`` call.

        Called by ``decode_async``'s rotation-retry path after a
        ``SignatureVerificationError``, so the retry fetches the current JWKS
        rather than reusing a stale cached key.
        """
        self._fetched_at = 0.0
