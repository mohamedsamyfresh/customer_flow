"""Decoded token payload, claims-mapper protocol, and the default mapper."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .config import AuthConfig
from .exceptions import InvalidTokenError


@dataclass(frozen=True, slots=True)
class TokenPayload:
    """Standardized, issuer-agnostic token payload.

    The decoded view of a JWT after signature/issuer/audience/expiry checks pass
    and the claims mapper has run. ``raw`` holds the full claims dict so services
    can read issuer-specific extras (``subject_type``, ``hr_team_name``, …)
    without the library hardcoding them as typed fields.

    Attributes:
        sub: Subject (typically the employee code).
        roles: Roles from the configured ``roles_claim``.
        permissions: Permissions from the configured ``permissions_claim``.
        raw: Full decoded claims dict (read-only view of issuer-specific extras).
    """

    sub: str
    roles: list[str]
    permissions: list[str]
    raw: dict[str, Any] = field(default_factory=dict[str, Any])

    def has_permission(self, permission: str) -> bool:
        """Return True if the user holds the given permission string."""
        return permission in self.permissions

    def has_role(self, role: str) -> bool:
        """Return True if the user holds the given role string."""
        return role in self.roles


@runtime_checkable
class ClaimsMapper(Protocol):
    """Callable that converts decoded claims into a ``TokenPayload``.

    Implement this to support a non-standard claim shape (e.g. Keycloak's nested
    ``realm_access.roles``). The mapper is called *after* signature/issuer/audience
    /expiry checks pass, so it only needs to extract and shape the payload.

    A mapper raising an ``AuthError`` subclass is re-raised as-is; any other
    exception (e.g. ``TypeError`` from a malformed claim) is caught and mapped
    to ``InvalidTokenError`` so a malformed claim never produces a 500.
    """

    def __call__(self, claims: dict[str, Any], config: AuthConfig) -> TokenPayload: ...


def default_mapper(claims: dict[str, Any], config: AuthConfig) -> TokenPayload:
    """Extract ``sub``/``roles``/``permissions`` using the configured claim names.

    Raises ``InvalidTokenError`` if the subject claim is missing or not a non-empty
    string. Roles/permissions default to empty lists when the claim is absent.
    """
    sub = claims.get(config.sub_claim)
    if not isinstance(sub, str) or not sub:
        raise InvalidTokenError(f"missing/empty {config.sub_claim!r} claim")
    roles = list(claims.get(config.roles_claim, []))
    permissions = list(claims.get(config.permissions_claim, []))
    return TokenPayload(sub=sub, roles=roles, permissions=permissions, raw=dict(claims))
